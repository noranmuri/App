//
//  CommunityListView.swift
//  challenge
//
//  Created by myeong on 2021/05/21.
//

import SwiftUI

struct CommunityListView: View {
    var body: some View {
        Text("커뮤니티")
    }
}

struct CommunityListView_Previews: PreviewProvider {
    static var previews: some View {
        CommunityListView()
    }
}
